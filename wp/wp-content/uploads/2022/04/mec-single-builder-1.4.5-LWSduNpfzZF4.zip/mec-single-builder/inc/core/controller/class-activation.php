<?php
namespace MEC_Single_Builder\Inc\Core\Controller;
use MEC_Single_Builder as NS;

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://webnus.net
 * @since      1.0.0
 *
 * @author     Webnus
 */
class Activation {

		public function __construct() {
			add_action( 'addons_activation', [ $this, 'add_addon_section' ] );
			add_action(	'wp_ajax_activate_Addons_Integration_SHB', array($this, 'activate_Addons_Integration_SHB'));
			add_action(	'wp_ajax_nopriv_activate_Addons_Integration_SHB', array($this, 'activate_Addons_Integration_SHB'));
			$options = get_option(NS\PLUGIN_OPTIONS);
			if ( isset($options['purchase_code']) && !empty( $options['purchase_code'] )) new License();
		}

			/**
		 * Description
		 *
		 * @since     1.0.0
		 */
		public function add_addon_section() {
			$addon_info = get_option( NS\PLUGIN_OPTIONS );
			$verify = NULL;
			$envato = new License();
			$verify = $envato->get_MEC_info('dl');

			$license_status = '';
			if(!empty($addon_info['purchase_code']) && !is_null($verify))
			{
				$license_status = 'PurchaseSuccess';
			} 
			elseif ( !empty($addon_info['purchase_code']) && is_null($verify) )
			{
				$license_status = 'PurchaseError';
			}
			echo '
				<style>.box-addon-activation-toggle-head {display: inline-block;}</style>
				<form id="'.NS\PLUGIN_TEXT_DOMAIN.'" class="addon-activation-form" action="#" method="post">
					<h3>'.esc_html__(NS\PLUGIN_ORG_NAME).'</h3>
					<div class="LicenseField">
						<input type="password" placeholder="Put your purchase code here" name="MECPurchaseCode" value="'. esc_html($addon_info['purchase_code']) .'">
						<input type="submit">
						<div class="MECPurchaseStatus '.esc_html($license_status).'"></div>
					</div>
					<div class="MECLicenseMessage"></div>
				</form>
				<script>
				if (jQuery("#'.NS\PLUGIN_TEXT_DOMAIN.'").length > 0)
				{
					jQuery("#'.NS\PLUGIN_TEXT_DOMAIN.' input[type=submit]").on("click", function(e){
						e.preventDefault();
						jQuery(".wna-spinner-wrap").remove();
						jQuery("#'.NS\PLUGIN_TEXT_DOMAIN.'").find(".MECLicenseMessage").text(" ");
						jQuery("#'.NS\PLUGIN_TEXT_DOMAIN.'").find(".MECPurchaseStatus").removeClass("PurchaseError");
						jQuery("#'.NS\PLUGIN_TEXT_DOMAIN.'").find(".MECPurchaseStatus").removeClass("PurchaseSuccess");
						var PurchaseCode = jQuery("#'.NS\PLUGIN_TEXT_DOMAIN.' input[type=password][name=MECPurchaseCode]").val();
						var information = { PurchaseCodeJson: PurchaseCode };
						jQuery.ajax({
							url: mec_admin_localize.ajax_url,
							type: "POST",
							data: {
								action: "activate_Addons_Integration_SHB",
								nonce: mec_admin_localize.ajax_nonce,
								content: information,
							},
							beforeSend: function () {
								jQuery("#'.NS\PLUGIN_TEXT_DOMAIN.' .LicenseField").append("<div class=\"wna-spinner-wrap\"><div class=\"wna-spinner\"><div class=\"double-bounce1\"></div><div class=\"double-bounce2\"></div></div></div>");
							},
							success: function (response) {
								if (response == "success")
								{
									jQuery(".wna-spinner-wrap").remove();
									jQuery("#'.NS\PLUGIN_TEXT_DOMAIN.'").find(".MECPurchaseStatus").addClass("PurchaseSuccess");
								}
								else
								{
									jQuery(".wna-spinner-wrap").remove();
									jQuery("#'.NS\PLUGIN_TEXT_DOMAIN.'").find(".MECPurchaseStatus").addClass("PurchaseError");
									jQuery("#'.NS\PLUGIN_TEXT_DOMAIN.'").find(".MECLicenseMessage").append(response);
								}
							},
						});
					});
				}
				</script>
			';
		}

		/**
		 * Description
		 *
		 * @since     1.0.0
		 */
		public function activate_Addons_Integration_SHB() {
			if(!wp_verify_nonce($_REQUEST['nonce'], 'mec_settings_nonce'))
			{
				exit();
			}

			$options = get_option( NS\PLUGIN_OPTIONS );
			$options['purchase_code'] = $_REQUEST['content']['PurchaseCodeJson'];
			$options['product_name'] = NS\PLUGIN_ORG_NAME;
			update_option( NS\PLUGIN_OPTIONS , $options);

			$verify = NULL;
			
			$envato = new License();
			$verify = $envato->get_MEC_info('dl');

			if(!is_null($verify))
			{
				$LicenseStatus = 'success';
			}
			else 
			{
				$LicenseStatus = __('Activation faild. Please check your purchase code or license type.<br><b>Note: Your purchase code should match your licesne type.</b>' , 'mec-single-builder') . '<a style="text-decoration: underline; padding-left: 7px;" href="https://webnus.ticksy.com/article/14445/" target="_blank">'  . __('Troubleshooting' , 'mec-single-builder') . '</a>';
			}

			echo $LicenseStatus;
			wp_die();
		}

}