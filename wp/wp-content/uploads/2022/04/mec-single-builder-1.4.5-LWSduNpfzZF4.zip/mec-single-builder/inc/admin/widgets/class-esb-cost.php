<?php
namespace Elementor;

namespace MEC_Single_Builder\Inc\Admin\Widgets;

use Elementor\Plugin;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class ESB_Cost extends \Elementor\Widget_Base
{

	/**
	 * Retrieve Alert widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{

		return 'event_cost';
	}

	/**
	 * Retrieve Alert widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title()
	{

		return __('Event Cost', 'mec-single-builder');
	}

	/**
	 * Retrieve Alert widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon()
	{

		return 'fa fa-usd';
	}

	/**
	 * Set widget category.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories()
	{

		return ['single_builder'];
	}

	/**
	 * Register Alert widget controls.
	 *
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls()
	{

		$this->start_controls_section(
			'mec_cost_box',
			array(
				'label' 	=> __('Cost Box', 'mec-single-builder'),
				'tab'   	=> \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'mec_cost_box_bg_color', //param_name
			[
				'label' 		=> __('Background Color', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::COLOR, //type
				'selectors' 	=> [
					'{{WRAPPER}} .mec-event-cost' => 'background: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'mec_cost_box_padding', //param_name
			[
				'label' 		=> __('Padding', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-event-cost' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'mec_cost_box_margin', //param_name
			[
				'label' 		=> __('Margin', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-event-cost' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 			=> 'mec_cost_box_border',
				'label' 		=> __('Border', 'mec-single-builder'),
				'selector' 		=> '{{WRAPPER}} .mec-event-cost',
			]
		);

		$this->add_control(
			'mec_cost_box_shape_radius', //param_name
			[
				'label' 		=> __('Border Radius', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-event-cost' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' 		=> 'mec_cost_box_box_shadow',
				'label' 	=> __('Box Shadow', 'mec-single-builder'),
				'selector' 	=> '{{WRAPPER}} .mec-event-cost',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'mec_cost_typography',
			array(
				'label' 	=> __('Cost Typography', 'mec-single-builder'),
				'tab'   	=> \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'mec_cost_typography_title',
				'label' 	=> __('Title Typography', 'mec-single-builder'),
				'selector' 	=> '{{WRAPPER}} .mec-event-cost .mec-cost',
			]
		);

		$this->add_control(
			'mec_cost_typography_color',
			[
				'label' 		=> __('Title Color', 'color'),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .mec-event-cost .mec-cost' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'mec_cost_typography_padding', //param_name
			[
				'label' 		=> __('Title Padding', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-event-cost .mec-cost' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'mec_cost_typography_icon',
			[
				'label' 		=> __('Icon Size', 'mec-single-builder'),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> ['px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' 		=> [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-event-cost i:before' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'mec_cost_typography_icon_color',
			[
				'label' 		=> __('Label Color', 'color'),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .mec-event-cost i:before' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'mec_cost_label_typography_title',
				'label' 	=> __('Label Typography', 'mec-single-builder'),
				'selector' 	=> '{{WRAPPER}} .mec-event-cost .mec-events-event-cost',
			]
		);

		$this->add_control(
			'mec_cost_label_typography_color',
			[
				'label' 		=> __('Label Color', 'color'),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .mec-event-cost .mec-events-event-cost' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'mec_cost_label_typography_padding', //param_name
			[
				'label' 		=> __('Label Padding', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-event-cost .mec-events-event-cost' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render Alert widget output on the frontend.
	 *
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render()
	{
		global $eventt;
		$mainClass      = new \MEC_main();
		$single         = new \MEC_skin_single();

		if (Plugin::$instance->editor->is_edit_mode()) {
			$latest_post = get_posts('post_type=mec-events&numberposts=1');
			$eventt = $single->get_event_mec($latest_post[0]->ID);
			$eventt = $eventt[0];
			// Event Cost
			if (isset($eventt->data->meta['mec_cost']) and $eventt->data->meta['mec_cost'] != '') {
				echo '<div class="mec-event-meta">';
				?>
			<div class="mec-event-cost">
				<i class="mec-sl-wallet"></i>
				<h3 class="mec-cost"><?php echo $mainClass->m('cost', __('Cost', 'mec-single-builder')); ?></h3>
				<dd class="mec-events-event-cost"><?php echo (is_numeric($eventt->data->meta['mec_cost']) ? $mainClass->render_price($eventt->data->meta['mec_cost']) : $eventt->data->meta['mec_cost']); ?></dd>
			</div>
			<?php
			echo '</div>';
		} else {
			echo '<div class="mec-content-notification">';
			echo '<p>';
			echo '<span>';
			echo __('This widget is displayed if cost is set. In order for the widget in this page to be displayed correctly, please set cost for your last event.', 'mec-single-builder');
			echo '</span>';
			echo '<a href="https://webnus.net/dox/modern-events-calendar/add-event/" target="_blank">' . __('How to set cost', 'mec-single-builder') . ' </a>';
			echo '</p>';
			echo '</div>';
		}
	} else {
		if ( isset($_GET['preview_id']) and !empty($_GET['preview_id'])) {
			$latest_post = get_posts('post_type=mec-events&numberposts=1');
			$e_id = $latest_post[0]->ID;
		} else {
			$e_id = get_the_ID();
		}
		$eventt = $single->get_event_mec($e_id);
		$eventt = $eventt[0];
		// Event Cost
		if (isset($eventt->data->meta['mec_cost']) and $eventt->data->meta['mec_cost'] != '') {
			echo '<div class="mec-event-meta">';
			?>
			<div class="mec-event-cost">
				<i class="mec-sl-wallet"></i>
				<h3 class="mec-cost"><?php echo $mainClass->m('cost', __('Cost', 'mec-single-builder')); ?></h3>
				<dd class="mec-events-event-cost"><?php echo (is_numeric($eventt->data->meta['mec_cost']) ? $mainClass->render_price($eventt->data->meta['mec_cost']) : $eventt->data->meta['mec_cost']); ?></dd>
			</div>
			<?php
			echo '</div>';
		}
	}
}
}
