<?php
/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://webnus.net
 * @since      1.0.0
 *
 * @author    Webnus
 */