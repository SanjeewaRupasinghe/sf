<?php
namespace Elementor;
namespace MEC_Single_Builder\Inc\Admin\Widgets;
use Elementor\Plugin;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow; 

class ESB_Organizer extends \Elementor\Widget_Base {

	/**
	 * Retrieve Alert widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {

		return 'event_organizer';
		
	}

	/**
	 * Retrieve Alert widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {

		return __( 'Event Organizers', 'mec-single-builder' );

	}

	/**
	 * Retrieve Alert widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {

		return 'eicon-person';

	}

	/**
	 * Set widget category.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories() {

		return [ 'single_builder' ];

	}

	/**
	 * Register Alert widget controls.
	 *
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
        'mec_organizer_typography',
            array(
                'label' 	=> __( 'Organizer Typography', 'mec-single-builder' ),
                'tab'   	=> \Elementor\Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' 		=> 'mec_organizer_typography_title',
                'label' 	=> __( 'Title Typography', 'mec-single-builder' ),
                'selector' 	=> '{{WRAPPER}} .mec-single-event-organizer .mec-events-single-section-title',
            ]
        );

        $this->add_control(
            'mec_organizer_typography_title_color',
            [
                'label' 		=> __( 'Title Color', 'color' ),
                'type' 			=> \Elementor\Controls_Manager::COLOR, 
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer .mec-events-single-section-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'mec_organizer_typography_title_padding', //param_name
            [
                'label' 		=> __( 'Title Padding', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
                'size_units' 	=> [ 'px', 'em', '%' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer .mec-events-single-section-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'mec_organizer_typography_title_margin', //param_name
            [
                'label' 		=> __( 'Title Padding', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
                'size_units' 	=> [ 'px', 'em', '%' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer .mec-events-single-section-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'mec_organizer_typography_icons_size',
            [
                'label' 		=> __( 'Icons Size', 'mec-single-builder' ),
                'type' 			=> Controls_Manager::SLIDER,
                'size_units' 	=> [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' 		=> [
                    'unit' => 'px',
                    'size' => 20,
                ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer dd i:before' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'mec_organizer_typography_icon_color',
            [
                'label' 		=> __( 'Icon Color', 'color' ),
                'type' 			=> \Elementor\Controls_Manager::COLOR, 
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer dd i:before' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' 		=> 'mec_organizer_bold_title_typography',
                'label' 	=> __( 'Label Typography', 'mec-single-builder' ),
                'selector' 	=> '{{WRAPPER}} .mec-single-event-organizer dd h6',
            ]
        );

        $this->add_control(
            'mec_organizer_bold_title_typography_color',
            [
                'label' 		=> __( 'Label Color', 'color' ),
                'type' 			=> \Elementor\Controls_Manager::COLOR, 
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer dd h6' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' 		=> 'mec_organizer_link_typography',
                'label' 	=> __( 'Link Typography', 'mec-single-builder' ),
                'selector' 	=> '{{WRAPPER}} .mec-single-event-organizer dd a',
            ]
        );

        $this->add_control(
            'mec_organizer_link_typography_color',
            [
                'label' 		=> __( 'Link Color', 'color' ),
                'type' 			=> \Elementor\Controls_Manager::COLOR, 
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer dd a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'mec_organizer_link_typography_color_hover',
            [
                'label' 		=> __( 'Link HoverColor', 'color' ),
                'type' 			=> \Elementor\Controls_Manager::COLOR, 
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer dd a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' 		=> 'mec_organizer_desc_typography',
                'label' 	=> __( 'Description Typography', 'mec-single-builder' ),
                'selector' 	=> '{{WRAPPER}} .mec-single-event-organizer dd p',
            ]
        );

        $this->add_control(
            'mec_organizer_desc_typography_color',
            [
                'label' 		=> __( 'Description Color', 'color' ),
                'type' 			=> \Elementor\Controls_Manager::COLOR, 
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer dd p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
        'mec_organizer_image_box',
            array(
                'label' 	=> __( 'Organizer Image Box', 'mec-single-builder' ),
                'tab'   	=> \Elementor\Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_responsive_control(
            'mec_organizer_image_width',
            [
                'label' 		=> __( 'Image Width', 'mec-single-builder' ),
                'type' 			=> Controls_Manager::SLIDER,
                'size_units' 	=> [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' 		=> [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer  .mec-img-organizer' => 'width: {{SIZE}}{{UNIT}}; display: block; height: auto;',
                ],
            ]
        );

        $this->add_responsive_control(
            'mec_organizer_image_height',
            [
                'label' 		=> __( 'Image Height', 'mec-single-builder' ),
                'type' 			=> Controls_Manager::SLIDER,
                'size_units' 	=> [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer  .mec-img-organizer' => 'height: {{SIZE}}{{UNIT}};  width: auto;',
                ],
            ]
        );

        $this->add_control(
            'mec_organizer_image_box_bg_color', //param_name
            [
                'label' 		=> __( 'Background Color', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::COLOR, //type
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer  .mec-img-organizer' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'mec_organizer_image_box_padding', //param_name
            [
                'label' 		=> __( 'Padding', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
                'size_units' 	=> [ 'px', 'em', '%' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer  .mec-img-organizer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'mec_organizer_image_box_margin', //param_name
            [
                'label' 		=> __( 'Margin', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
                'size_units' 	=> [ 'px', 'em', '%' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer  .mec-img-organizer' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' 			=> 'mec_organizer_image_box_border',
                'label' 		=> __( 'Border', 'mec-single-builder' ),
                'selector' 		=> '{{WRAPPER}} .mec-single-event-organizer  .mec-img-organizer',
            ]
        );

        $this->add_control(
            'mec_organizer_image_box_border_radius',
            [
                'label' 		=> __( 'Border Radius', 'mec-single-builder' ),
                'type' 			=> \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' 	=> [ 'px', 'em', '%' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer  .mec-img-organizer' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
                [
                    'name' 		=> 'mec_organizer_image_box_shadow',
                    'label' 	=> __( 'Box Shadow', 'mec-single-builder' ),
                    'selector' 	=> '{{WRAPPER}} .mec-single-event-organizer  .mec-img-organizer',
                ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
        'mec_organizer_box',
            array(
                'label' 	=> __( 'Organizer Box', 'mec-single-builder' ),
                'tab'   	=> \Elementor\Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'mec_organizer_box_bg_color', //param_name
            [
                'label' 		=> __( 'Background Color', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::COLOR, //type
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'mec_organizer_box_padding', //param_name
            [
                'label' 		=> __( 'Padding', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
                'size_units' 	=> [ 'px', 'em', '%' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'mec_organizer_box_margin', //param_name
            [
                'label' 		=> __( 'Margin', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
                'size_units' 	=> [ 'px', 'em', '%' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' 			=> 'mec_organizer_box_border',
                'label' 		=> __( 'Border', 'mec-single-builder' ),
                'selector' 		=> '{{WRAPPER}} .mec-single-event-organizer',
            ]
        );

        $this->add_control(
            'mec_organizer_box_shape_radius', //param_name
            [
                'label' 		=> __( 'Border Radius', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
                'size_units' 	=> [ 'px', 'em', '%' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-organizer' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
                [
                    'name' 		=> 'mec_organizer_box_box_shadow',
                    'label' 	=> __( 'Box Shadow', 'mec-single-builder' ),
                    'selector' 	=> '{{WRAPPER}} .mec-single-event-organizer',
                ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
        'mec_other_organizer_typography',
            array(
                'label' 	=> __( 'Other Organizer Typography', 'mec-single-builder' ),
                'tab'   	=> \Elementor\Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_responsive_control(
            'mec_other_organizer_typography_icons_size',
            [
                'label' 		=> __( 'Icons Size', 'mec-single-builder' ),
                'type' 			=> Controls_Manager::SLIDER,
                'size_units' 	=> [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' 		=> [
                    'unit' => 'px',
                    'size' => 20,
                ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers dd i:before' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'mec_other_organizer_typography_icon_color',
            [
                'label' 		=> __( 'Icon Color', 'color' ),
                'type' 			=> \Elementor\Controls_Manager::COLOR, 
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers dd i:before' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' 		=> 'mec_other_organizer_bold_title_typography',
                'label' 	=> __( 'Label Typography', 'mec-single-builder' ),
                'selector' 	=> '{{WRAPPER}} .mec-single-event-additional-organizers dd h6',
            ]
        );

        $this->add_control(
            'mec_other_organizer_bold_title_typography_color',
            [
                'label' 		=> __( 'Label Color', 'color' ),
                'type' 			=> \Elementor\Controls_Manager::COLOR, 
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers dd h6' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' 		=> 'mec_other_organizer_link_typography',
                'label' 	=> __( 'Link Typography', 'mec-single-builder' ),
                'selector' 	=> '{{WRAPPER}} .mec-single-event-additional-organizers dd a',
            ]
        );

        $this->add_control(
            'mec_other_organizer_link_typography_color',
            [
                'label' 		=> __( 'Link Color', 'color' ),
                'type' 			=> \Elementor\Controls_Manager::COLOR, 
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers dd a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'mec_other_organizer_link_typography_color_hover',
            [
                'label' 		=> __( 'Link HoverColor', 'color' ),
                'type' 			=> \Elementor\Controls_Manager::COLOR, 
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers dd a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' 		=> 'mec_other_organizer_desc_typography',
                'label' 	=> __( 'Description Typography', 'mec-single-builder' ),
                'selector' 	=> '{{WRAPPER}} .mec-single-event-additional-organizers dd p',
            ]
        );

        $this->add_control(
            'mec_other_organizer_desc_typography_color',
            [
                'label' 		=> __( 'Description Color', 'color' ),
                'type' 			=> \Elementor\Controls_Manager::COLOR, 
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers dd p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
        'mec_other_organizer_image_box',
            array(
                'label' 	=> __( 'Other Organizer Image Box', 'mec-single-builder' ),
                'tab'   	=> \Elementor\Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_responsive_control(
            'mec_other_organizer_image_width',
            [
                'label' 		=> __( 'Image Width', 'mec-single-builder' ),
                'type' 			=> Controls_Manager::SLIDER,
                'size_units' 	=> [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' 		=> [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers  .mec-img-organizer' => 'width: {{SIZE}}{{UNIT}}; display: block; height: auto;',
                ],
            ]
        );

        $this->add_responsive_control(
            'mec_other_organizer_image_height',
            [
                'label' 		=> __( 'Image Height', 'mec-single-builder' ),
                'type' 			=> Controls_Manager::SLIDER,
                'size_units' 	=> [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers  .mec-img-organizer' => 'height: {{SIZE}}{{UNIT}}; width: auto;',
                ],
            ]
        );

        $this->add_control(
            'mec_other_organizer_image_box_bg_color', //param_name
            [
                'label' 		=> __( 'Background Color', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::COLOR, //type
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers  .mec-img-organizer' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'mec_other_organizer_image_box_padding', //param_name
            [
                'label' 		=> __( 'Padding', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
                'size_units' 	=> [ 'px', 'em', '%' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers  .mec-img-organizer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'mec_other_organizer_image_box_margin', //param_name
            [
                'label' 		=> __( 'Margin', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
                'size_units' 	=> [ 'px', 'em', '%' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers  .mec-img-organizer' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' 			=> 'mec_other_organizer_image_box_border',
                'label' 		=> __( 'Border', 'mec-single-builder' ),
                'selector' 		=> '{{WRAPPER}} .mec-single-event-additional-organizers  .mec-img-organizer',
            ]
        );

        $this->add_control(
            'mec_other_organizer_image_box_border_radius',
            [
                'label' 		=> __( 'Border Radius', 'mec-single-builder' ),
                'type' 			=> \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' 	=> [ 'px', 'em', '%' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers  .mec-img-organizer' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
                [
                    'name' 		=> 'mec_other_organizer_image_box_shadow',
                    'label' 	=> __( 'Box Shadow', 'mec-single-builder' ),
                    'selector' 	=> '{{WRAPPER}} .mec-single-event-additional-organizers  .mec-img-organizer',
                ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
        'mec_other_organizer_box',
            array(
                'label' 	=> __( 'Other Organizer Box', 'mec-single-builder' ),
                'tab'   	=> \Elementor\Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'mec_other_organizer_box_bg_color', //param_name
            [
                'label' 		=> __( 'Background Color', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::COLOR, //type
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers .mec-single-event-additional-organizer' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'mec_other_organizer_box_padding', //param_name
            [
                'label' 		=> __( 'Padding', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
                'size_units' 	=> [ 'px', 'em', '%' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers .mec-single-event-additional-organizer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'mec_other_organizer_box_margin', //param_name
            [
                'label' 		=> __( 'Margin', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
                'size_units' 	=> [ 'px', 'em', '%' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers .mec-single-event-additional-organizer' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' 			=> 'mec_other_organizer_box_border',
                'label' 		=> __( 'Border', 'mec-single-builder' ),
                'selector' 		=> '{{WRAPPER}} .mec-single-event-additional-organizers .mec-single-event-additional-organizer',
            ]
        );

        $this->add_control(
            'mec_other_organizer_box_shape_radius', //param_name
            [
                'label' 		=> __( 'Border Radius', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
                'size_units' 	=> [ 'px', 'em', '%' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers .mec-single-event-additional-organizer' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
                [
                    'name' 		=> 'mec_other_organizer_box_box_shadow',
                    'label' 	=> __( 'Box Shadow', 'mec-single-builder' ),
                    'selector' 	=> '{{WRAPPER}} .mec-single-event-additional-organizers .mec-single-event-additional-organizer',
                ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
        'mec_additional_organizer_box',
            array(
                'label' 	=> __( 'Additional Organizer Box', 'mec-single-builder' ),
                'tab'   	=> \Elementor\Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' 		=> 'mec_additional_organizer_typography_title',
                'label' 	=> __( 'Title Typography', 'mec-single-builder' ),
                'selector' 	=> '{{WRAPPER}} .mec-single-event-additional-organizers .mec-events-single-section-title',
            ]
        );

        $this->add_control(
            'mec_other_organizer_typography_title_color',
            [
                'label' 		=> __( 'Title Color', 'color' ),
                'type' 			=> \Elementor\Controls_Manager::COLOR, 
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers .mec-events-single-section-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'mec_other_organizer_typography_title_padding', //param_name
            [
                'label' 		=> __( 'Title Padding', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
                'size_units' 	=> [ 'px', 'em', '%' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers .mec-events-single-section-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'mec_additional_organizer_box_bg_color', //param_name
            [
                'label' 		=> __( 'Additional Background Color', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::COLOR, //type
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'mec_additional_organizer_box_padding', //param_name
            [
                'label' 		=> __( 'Additional Padding', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
                'size_units' 	=> [ 'px', 'em', '%' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'mec_additional_organizer_box_margin', //param_name
            [
                'label' 		=> __( 'Additional Margin', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
                'size_units' 	=> [ 'px', 'em', '%' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' 			=> 'mec_additional_organizer_box_border',
                'label' 		=> __( 'Additional Border', 'mec-single-builder' ),
                'selector' 		=> '{{WRAPPER}} .mec-single-event-additional-organizers',
            ]
        );

        $this->add_control(
            'mec_additional_organizer_box_shape_radius', //param_name
            [
                'label' 		=> __( 'Additional Border Radius', 'mec-single-builder' ), //heading
                'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
                'size_units' 	=> [ 'px', 'em', '%' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .mec-single-event-additional-organizers' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
                [
                    'name' 		=> 'mec_additional_organizer_box_box_shadow',
                    'label' 	=> __( 'Additional Box Shadow', 'mec-single-builder' ),
                    'selector' 	=> '{{WRAPPER}} .mec-single-event-additional-organizers',
                ]
        );

        $this->end_controls_section();        

	}

	/**
	 * Render Alert widget output on the frontend.
	 *
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		global $eventt;
		$mainClass      = new \MEC_main();
        $single         = new \MEC_skin_single();
        $set            = $mainClass->get_settings();

		if ( Plugin::$instance->editor->is_edit_mode() ) {
			$latest_post = get_posts( 'post_type=mec-events&numberposts=1' );
            $eventt = $single->get_event_mec($latest_post[0]->ID);
            $eventt = $eventt[0];
            // Event Organizer
            if(isset($eventt->data->organizers[$eventt->data->meta['mec_organizer_id']]) && !empty($eventt->data->organizers[$eventt->data->meta['mec_organizer_id']]) ) { 
                echo '<div class="mec-event-meta">';
                $organizer = $eventt->data->organizers[$eventt->data->meta['mec_organizer_id']];
                ?>
                <div class="mec-single-event-organizer">
                    <?php if(isset($organizer['thumbnail']) and trim($organizer['thumbnail'])): ?>
                        <img class="mec-img-organizer" src="<?php echo esc_url($organizer['thumbnail']); ?>" alt="<?php echo (isset($organizer['name']) ? $organizer['name'] : ''); ?>">
                    <?php endif; ?>
                    <h3 class="mec-events-single-section-title"><?php echo $mainClass->m('taxonomy_organizer', __('Organizer', 'mec-single-builder')); ?></h3>
                    <?php if(isset($organizer['thumbnail'])): ?>
                        <dd class="mec-organizer">
                            <i class="mec-sl-home"></i>
                            <h6><?php echo (isset($organizer['name']) ? $organizer['name'] : ''); ?></h6>
                        </dd>
                    <?php endif;
                    if(isset($organizer['tel']) && !empty($organizer['tel'])): ?>
                    <dd class="mec-organizer-tel">
                        <i class="mec-sl-phone"></i>
                        <h6><?php _e('Phone', 'mec-single-builder'); ?></h6>
                        <a href="tel:<?php echo $organizer['tel']; ?>"><?php echo $organizer['tel']; ?></a>
                    </dd>
                    <?php endif; 
                    if(isset($organizer['email']) && !empty($organizer['email'])): ?>
                    <dd class="mec-organizer-email">
                        <i class="mec-sl-envelope"></i>
                        <h6><?php _e('Email', 'mec-single-builder'); ?></h6>
                        <a href="mailto:<?php echo $organizer['email']; ?>"><?php echo $organizer['email']; ?></a>
                    </dd>
                    <?php endif;
                    if(isset($organizer['url']) && !empty($organizer['url']) and $organizer['url'] != 'http://'): ?>
                    <dd class="mec-organizer-url">
                        <i class="mec-sl-sitemap"></i>
                        <h6><?php _e('Website', 'mec-single-builder'); ?></h6>
                        <span><a href="<?php echo (strpos($organizer['url'], 'http') === false ? 'http://'.$organizer['url'] : $organizer['url']); ?>" class="mec-color-hover" target="_blank"><?php echo $organizer['url']; ?></a></span>
                    </dd>
                    <?php endif;
                    $organizer_description_setting = isset( $set['organizer_description'] ) ? $set['organizer_description'] : ''; $organizer_terms = get_the_terms($eventt->data, 'mec_organizer');  if($organizer_description_setting == '1'): foreach($organizer_terms as $organizer_term) { if ($organizer_term->term_id == $organizer['id'] ) {  if(isset($organizer_term->description) && !empty($organizer_term->description)): ?>
                    <dd class="mec-organizer-description">
                        <p><?php echo $organizer_term->description;?></p>
                    </dd>
                    <?php endif; } } endif; ?>
                </div>
                <?php
                $single->show_other_organizers($eventt); // Show Additional Organizers
                echo '</div>';
            } else {
				echo '<div class="mec-content-notification">';
				echo '<p>';
				echo '<span>';
				echo __('This widget is displayed if organizer is set. In order for the widget in this page to be displayed correctly, please set organizer for your last event.', 'mec-single-builder');
				echo '</span>';
				echo '<a href="https://webnus.net/dox/modern-events-calendar/organizer-and-other-organizer/" target="_blank">' . __('How to set organizer', 'mec-single-builder') . ' </a>';
				echo '</p>';
				echo '</div>';
            }
		} else {
            if ( isset($_GET['preview_id']) and !empty($_GET['preview_id'])) {
                $latest_post = get_posts('post_type=mec-events&numberposts=1');
                $e_id = $latest_post[0]->ID;
            } else {
                $e_id = get_the_ID();
            }
            $eventt = $single->get_event_mec($e_id);
            $eventt = $eventt[0];
            // Event Organizer
            if(isset($eventt->data->organizers[$eventt->data->meta['mec_organizer_id']]) && !empty($eventt->data->organizers[$eventt->data->meta['mec_organizer_id']]) ) {
                echo '<div class="mec-event-meta">';
                $organizer = $eventt->data->organizers[$eventt->data->meta['mec_organizer_id']];
                ?>
                <div class="mec-single-event-organizer">
                    <?php if(isset($organizer['thumbnail']) and trim($organizer['thumbnail'])): ?>
                        <img class="mec-img-organizer" src="<?php echo esc_url($organizer['thumbnail']); ?>" alt="<?php echo (isset($organizer['name']) ? $organizer['name'] : ''); ?>">
                    <?php endif; ?>
                    <h3 class="mec-events-single-section-title"><?php echo $mainClass->m('taxonomy_organizer', __('Organizer', 'mec-single-builder')); ?></h3>
                    <?php if(isset($organizer['thumbnail'])): ?>
                        <dd class="mec-organizer">
                            <i class="mec-sl-home"></i>
                            <h6><?php echo (isset($organizer['name']) ? $organizer['name'] : ''); ?></h6>
                        </dd>
                    <?php endif;
                    if(isset($organizer['tel']) && !empty($organizer['tel'])): ?>
                    <dd class="mec-organizer-tel">
                        <i class="mec-sl-phone"></i>
                        <h6><?php _e('Phone', 'mec-single-builder'); ?></h6>
                        <a href="tel:<?php echo $organizer['tel']; ?>"><?php echo $organizer['tel']; ?></a>
                    </dd>
                    <?php endif; 
                    if(isset($organizer['email']) && !empty($organizer['email'])): ?>
                    <dd class="mec-organizer-email">
                        <i class="mec-sl-envelope"></i>
                        <h6><?php _e('Email', 'mec-single-builder'); ?></h6>
                        <a href="mailto:<?php echo $organizer['email']; ?>"><?php echo $organizer['email']; ?></a>
                    </dd>
                    <?php endif;
                    if(isset($organizer['url']) && !empty($organizer['url']) and $organizer['url'] != 'http://'): ?>
                    <dd class="mec-organizer-url">
                        <i class="mec-sl-sitemap"></i>
                        <h6><?php _e('Website', 'mec-single-builder'); ?></h6>
                        <span><a href="<?php echo (strpos($organizer['url'], 'http') === false ? 'http://'.$organizer['url'] : $organizer['url']); ?>" class="mec-color-hover" target="_blank"><?php echo $organizer['url']; ?></a></span>
                    </dd>
                    <?php endif;
                    $organizer_description_setting = isset( $set['organizer_description'] ) ? $set['organizer_description'] : ''; $organizer_terms = get_the_terms($eventt->data, 'mec_organizer');  if($organizer_description_setting == '1'): foreach($organizer_terms as $organizer_term) { if ($organizer_term->term_id == $organizer['id'] ) {  if(isset($organizer_term->description) && !empty($organizer_term->description)): ?>
                    <dd class="mec-organizer-description">
                        <p><?php echo $organizer_term->description;?></p>
                    </dd>
                    <?php endif; } } endif; ?>
                </div>
                <?php
                $single->show_other_organizers($eventt); // Show Additional Organizers
                echo '</div>';
            }
		}

	}

}