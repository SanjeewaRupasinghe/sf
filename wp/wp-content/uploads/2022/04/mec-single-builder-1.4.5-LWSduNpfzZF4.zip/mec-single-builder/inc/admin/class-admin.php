<?php
namespace MEC_Single_Builder\Inc\Admin;
use MEC_Single_Builder as NS;
use Elementor\Plugin;
use Elementor\Post_CSS_File;
use Elementor\Core\Files\CSS\Post;

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @link       https://webnus.net
 * @since      1.0.0
 *
 * @author    Webnus
 */
class Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * The text domain of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_text_domain    The text domain of this plugin.
	 */
	private $plugin_text_domain;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since       1.0.0
	 * @param       string $plugin_name        The name of this plugin.
	 * @param       string $version            The version of this plugin.
	 * @param       string $plugin_text_domain The text domain of this plugin.
	 */
	public function __construct( $plugin_name, $version, $plugin_text_domain )
	{

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		$this->plugin_text_domain = $plugin_text_domain;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles()
	{

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/mec-single-builder-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts()
	{

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/mec-single-builder-admin.js', array( 'jquery' ), $this->version, false );

	}

	/**
	 * Register mec_esb post type
	 *
	 * @since    1.0.0
	 */
	public function mec_esb_post_type()
	{
		// Set UI labels for Custom Post Type
		$labels = array(
			'name'                => _x( 'Single Builders', 'Post Type General Name', 'twentythirteen' ),
			'singular_name'       => _x( 'Single Builder', 'Post Type Singular Name', 'twentythirteen' ),
			'menu_name'           => __( 'Single Builders', 'twentythirteen' ),
			'parent_item_colon'   => __( 'Parent Single Builder', 'twentythirteen' ),
			'all_items'           => __( 'All Single Builders', 'twentythirteen' ),
			'view_item'           => __( 'View Single Builder', 'twentythirteen' ),
			'add_new_item'        => __( 'Add New Single Builder', 'twentythirteen' ),
			'add_new'             => __( 'Add New', 'twentythirteen' ),
			'edit_item'           => __( 'Edit Single Builder', 'twentythirteen' ),
			'update_item'         => __( 'Update Single Builder', 'twentythirteen' ),
			'search_items'        => __( 'Search Single Builder', 'twentythirteen' ),
			'not_found'           => __( 'Not Found', 'twentythirteen' ),
			'not_found_in_trash'  => __( 'Not found in Trash', 'twentythirteen' ),
		);

		$args = array(
			'label'               => __( 'Single Builders', 'twentythirteen' ),
			'description'         => __( 'Single Builder news and reviews', 'twentythirteen' ),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => false,
			'query_var'          => true,
			'rewrite'            => [ 'slug' => 'mec_esb' ],
			'has_archive'        => true,
			'hierarchical'       => true,
			'supports'           => [ 'title', 'editor', 'elementor' ],
			'labels'              => $labels,
			'exclude_from_search' => true

		);

		register_post_type( 'mec_esb', $args );
	}
	
	public function create_esb_post()
	{

		global $wpdb;
		$post_title = 'Single Builder';
		
		$query = $wpdb->prepare(
			'SELECT * FROM ' . $wpdb->posts . ' WHERE post_title = %s AND post_type = \'mec_esb\' order by \'publish_date\' desc',$post_title
		);
		$wpdb->query( $query );

		if ( $wpdb->num_rows ) :

			$post = $wpdb->get_row( $query );
			return $post->ID;

		else:

			$new_post   = [
				'post_title'    => $post_title,
				'post_content'  => '',
				'post_status'   => 'publish',
				'post_date'     => date( 'Y-m-d H:i:s' ),
				'post_author'   => '1',
				'post_type'     => 'mec_esb',
				'post_category' => [ 0 ],
			];
			
			$post_id = wp_insert_post( $new_post );
			$sb_post = get_post( $post_id );

			update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
			update_post_meta( $post_id, '_elementor_template_type', 'post' );
			update_post_meta( $post_id, '_wp_page_template', 'default' );
			update_post_meta( $post_id, '_edit_lock', time() . ':1' );
			update_post_meta( $post_id, '_elementor_version', '0.4' );
			update_post_meta( $post_id, '_elementor_data', '' );

			return $post_id;

		endif;

	}

	public function esb_single($single)
	{

		global $post;

		if ( $post->post_type == 'mec_esb' )
		{
			if ( file_exists( NS\PLUGIN_NAME_DIR . 'inc/frontend/views/single-mec_esb.php' ) )
			{
				return NS\PLUGIN_NAME_DIR . 'inc/frontend/views/single-mec_esb.php';
			}
		}

		return $single;

	}

	public function load_the_builder($event)
	{
		global $eventt;
		$eventt = $event;

		$post_title = 'Single Builder';
		if ( ! class_exists( '\Elementor\Plugin' ) ) return;
		
		if ( isset( $_REQUEST['elementor-preview'] ) && \Elementor\Plugin::$instance->preview->is_preview_mode() ) {
			if ( get_the_title() != $post_title ) return;
		}
		
		global $wpdb;
		$query = $wpdb->prepare(
			'SELECT ID FROM ' . $wpdb->posts . '
			WHERE post_title = %s
			AND post_type = \'mec_esb\'',
			$post_title
		);
		$wpdb->query( $query );

		if ( $wpdb->num_rows ) {
			$post_id = $wpdb->get_var( $query );
		}

		echo '<div class="mec-wrap mec-single-builder-wrap"><div class="row mec-single-event"><div class="wn-single">' . Plugin::instance()->frontend->get_builder_content_for_display( $post_id, true ) . '</div></div></div>';

		if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) )
		{
			$css_file = new Post( $post_id );
		} 
		elseif ( class_exists( '\Elementor\Post_CSS_File' ) )
		{
			$css_file = new Post_CSS_File( $post_id );
		}
		$css_file->enqueue();

	}

	public function esb_submenu()
	{

		global $wpdb;
		$post_title = 'Single Builder';
		$query = $wpdb->prepare(
			'SELECT ID FROM ' . $wpdb->posts . '
			WHERE post_title = %s
			AND post_type = \'mec_esb\'',
			$post_title
		);
		$wpdb->query( $query );

		if ( $wpdb->num_rows ) {
			$post_id = $wpdb->get_var( $query );
		}
		global $submenu;
		add_submenu_page( 'mec-intro', __( 'Single Builder', 'mec-single-builder' ), __( 'Single Builder', 'mec-single-builder' ), 'edit_posts', 'post.php?post='.$post_id.'&action=elementor' );
		
	}

	public function disable_mec_esb_page() {
		if (isset($_GET['post_type']) && $_GET['post_type'] == 'mec_esb') {
			header("Location: " . admin_url());
			exit();
		}
	}
	
	
}