<?php
namespace Elementor;

namespace MEC_Single_Builder\Inc\Admin\Widgets;

use Elementor\Plugin;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class ESB_RegisterButton extends \Elementor\Widget_Base
{

	/**
	 * Retrieve Alert widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{

		return 'event_register_button';
	}

	/**
	 * Retrieve Alert widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title()
	{

		return __('Event Register Button', 'mec-single-builder');
	}

	/**
	 * Retrieve Alert widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon()
	{

		return 'eicon-button';
	}

	/**
	 * Set widget category.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories()
	{

		return ['single_builder'];
	}

	/**
	 * Register Alert widget controls.
	 *
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls()
	{

		$this->start_controls_section(
			'mec_regbtn_box',
			array(
				'label' 	=> __('Register Button Box', 'mec-single-builder'),
				'tab'   	=> \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'mec_regbtn_box_bg_color', //param_name
			[
				'label' 		=> __('Background Color', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::COLOR, //type
				'selectors' 	=> [
					'{{WRAPPER}} .mec-reg-btn.mec-frontbox' => 'background: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'mec_regbtn_box_padding', //param_name
			[
				'label' 		=> __('Padding', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-reg-btn.mec-frontbox' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'mec_regbtn_box_margin', //param_name
			[
				'label' 		=> __('Margin', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-reg-btn.mec-frontbox' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 			=> 'mec_regbtn_box_border',
				'label' 		=> __('Border', 'mec-single-builder'),
				'selector' 		=> '{{WRAPPER}} .mec-reg-btn.mec-frontbox',
			]
		);

		$this->add_control(
			'mec_regbtn_box_shape_radius', //param_name
			[
				'label' 		=> __('Border Radius', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-reg-btn.mec-frontbox' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' 		=> 'mec_regbtn_box_box_shadow',
				'label' 	=> __('Box Shadow', 'mec-single-builder'),
				'selector' 	=> '{{WRAPPER}} .mec-reg-btn.mec-frontbox',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'mec_regbtn_typography',
			array(
				'label' 	=> __('Register Button', 'mec-single-builder'),
				'tab'   	=> \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'mec_regbtn_typography_title',
				'label' 	=> __('Button Typography', 'mec-single-builder'),
				'selector' 	=> '{{WRAPPER}} .mec-reg-btn.mec-frontbox .mec-booking-button',
			]
		);

		$this->add_control(
			'mec_regbtn_typography_color',
			[
				'label' 		=> __('Text Color', 'color'),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .mec-reg-btn.mec-frontbox .mec-booking-button' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'mec_regbtn_typography_color_hover',
			[
				'label' 		=> __('Text Hover Color', 'color'),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .mec-reg-btn.mec-frontbox .mec-booking-button:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'mec_regbtn_typography_padding', //param_name
			[
				'label' 		=> __('Button Padding', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-reg-btn.mec-frontbox .mec-booking-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'mec_regbtn_typography_margin', //param_name
			[
				'label' 		=> __('Button Margin', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-reg-btn.mec-frontbox .mec-booking-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'mec_regbtn_box_width',
			[
				'label' 		=> __('Button Width', 'mec-single-builder'),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> ['px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' 		=> [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' 	=> [
					'.mec-single-event {{WRAPPER}} .mec-booking-button' => 'width: {{SIZE}}{{UNIT}} !important;',
				],
			]
		);

		$this->add_responsive_control(
			'mec_regbtn_btn_height',
			[
				'label' 		=> __('Button Height', 'mec-single-builder'),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> ['px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
					'default' 		=> [
						'unit' => '%',
						'size' => 100,
					],					
				],
				'selectors' 	=> [
					'.mec-single-event {{WRAPPER}} .mec-booking-button' => 'height: {{SIZE}}{{UNIT}} !important;',
				],
			]
		);

		$this->add_control(
			'mec_regbtn_typography_bgcolor',
			[
				'label' 		=> __('Button Background Color', 'color'),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .mec-reg-btn.mec-frontbox .mec-booking-button' => 'background: {{VALUE}} !important',
				],
			]
		);

		$this->add_control(
			'mec_regbtn_typography_bgcolor_hover',
			[
				'label' 		=> __('Button Hover Background Color', 'color'),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .mec-reg-btn.mec-frontbox .mec-booking-button:hover' => 'background: {{VALUE}} !important',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 			=> 'mec_regbtn_typo_border',
				'label' 		=> __('Border', 'mec-single-builder'),
				'selector' 		=> '{{WRAPPER}} .mec-reg-btn.mec-frontbox .mec-booking-button',
			]
		);

		$this->add_control(
			'mec_regbtn_typo_shape_radius', //param_name
			[
				'label' 		=> __('Border Radius', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-reg-btn.mec-frontbox .mec-booking-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' 		=> 'mec_regbtn_typo_box_shadow',
				'label' 	=> __('Box Shadow', 'mec-single-builder'),
				'selector' 	=> '{{WRAPPER}} .mec-reg-btn.mec-frontbox .mec-booking-button',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render Alert widget output on the frontend.
	 *
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render()
	{
		global $eventt;
		$mainClass      = new \MEC_main();
		$single         = new \MEC_skin_single();
		$set            = $mainClass->get_settings();

		if (Plugin::$instance->editor->is_edit_mode()) {
			$latest_post = get_posts('post_type=mec-events&numberposts=1');
			$eventt = $single->get_event_mec($latest_post[0]->ID);
			$eventt = $eventt[0];
			?>
		<!-- Register Booking Button -->
		<?php if ($mainClass->can_show_booking_module($eventt)) : ?>
			<div class="mec-reg-btn mec-frontbox">
				<?php $data_lity = '';
				if (isset($set['single_booking_style']) and $set['single_booking_style'] == 'modal') $data_lity = 'data-lity'; ?>
				<a class="mec-booking-button mec-bg-color <?php if (isset($set['single_booking_style']) and $set['single_booking_style'] != 'modal') echo 'simple-booking'; ?>" href="#mec-events-meta-group-booking-<?php echo $single->uniqueid; ?>" <?php echo $data_lity; ?>><?php echo esc_html($mainClass->m('register_button', __('REGISTER', 'mec-single-builder'))); ?></a>
				<script>
				// Fix modal booking in some themes
				jQuery( ".mec-booking-button.mec-booking-data-lity" ).click(function(e)
				{
					e.preventDefault();
					var book_id =  jQuery(this).attr('href');
					lity(book_id);
				});
				</script>
			<?php elseif (isset($eventt->data->meta['mec_more_info']) and trim($eventt->data->meta['mec_more_info']) and $eventt->data->meta['mec_more_info'] != 'http://') : ?>
				<a target="<?php echo (isset($eventt->data->meta['mec_more_info_target']) ? $eventt->data->meta['mec_more_info_target'] : '_self'); ?>" class="mec-booking-button mec-bg-color" href="<?php echo $eventt->data->meta['mec_more_info']; ?>"><?php if (isset($eventt->data->meta['mec_more_info_title']) and trim($eventt->data->meta['mec_more_info_title'])) echo esc_html(trim($eventt->data->meta['mec_more_info_title']), 'mec-single-builder');
				else echo esc_html($mainClass->m('register_button', __('REGISTER', 'mec-single-builder')));
				?></a>
			</div>
		<?php
	else :
		echo '<div class="mec-content-notification">';
		echo '<p>';
		echo '<span>';
		echo __('This widget is displayed if register button is set. In order for the widget in this page to be displayed correctly, please set register button for your last event.', 'mec-single-builder');
		echo '</span>';
		echo '<a href="https://webnus.net/dox/modern-events-calendar/booking/" target="_blank">' . __('How to set register button', 'mec-single-builder') . ' </a>';
		echo '</p>';
		echo '</div>';
		?>
		<?php endif; ?>
	<?php

} else {
	if ( isset($_GET['preview_id']) and !empty($_GET['preview_id'])) {
		$latest_post = get_posts('post_type=mec-events&numberposts=1');
		$e_id = $latest_post[0]->ID;
	} else {
		$e_id = get_the_ID();
	}
	$eventt = $single->get_event_mec($e_id);
	$eventt = $eventt[0];
	?>
		<!-- Register Booking Button -->
		<div class="mec-reg-btn mec-frontbox">
		<?php if ($mainClass->can_show_booking_module($eventt)) : ?>
				<?php $data_lity = '';
				if (isset($set['single_booking_style']) and $set['single_booking_style'] == 'modal')  $data_lity_class = 'mec-booking-data-lity'; ?>
				<a class="mec-booking-button mec-bg-color <?php echo $data_lity_class; ?> <?php if (isset($set['single_booking_style']) and $set['single_booking_style'] != 'modal') echo 'simple-booking'; ?>" href="#mec-events-meta-group-booking-<?php echo $single->uniqueid; ?>"><?php echo esc_html($mainClass->m('register_button', __('REGISTER', 'mec-single-builder'))); ?></a>
				<script>
				// Fix modal booking in some themes
				jQuery( ".mec-booking-button.mec-booking-data-lity" ).click(function(e)
				{
					e.preventDefault();
					var book_id =  jQuery(this).attr('href');
					lity(book_id);
				});
				</script>
		<?php elseif (isset($eventt->data->meta['mec_more_info']) and trim($eventt->data->meta['mec_more_info']) and $eventt->data->meta['mec_more_info'] != 'http://') : ?>
				<a class="mec-booking-button mec-bg-color" target="<?php echo (isset($eventt->data->meta['mec_more_info_target']) ? $eventt->data->meta['mec_more_info_target'] : '_self'); ?>" href="<?php echo $eventt->data->meta['mec_more_info']; ?>"><?php if (isset($eventt->data->meta['mec_more_info_title']) and trim($eventt->data->meta['mec_more_info_title'])) echo esc_html(trim($eventt->data->meta['mec_more_info_title']), 'mec-single-builder');
				else echo esc_html($mainClass->m('register_button', __('REGISTER', 'mec-single-builder')));
				?></a>
		<?php endif; ?>
		</div>
	<?php
}
}
}
