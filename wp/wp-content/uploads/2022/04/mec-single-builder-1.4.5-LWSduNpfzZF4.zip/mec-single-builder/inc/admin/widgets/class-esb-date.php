<?php
namespace Elementor;

namespace MEC_Single_Builder\Inc\Admin\Widgets;

use Elementor\Plugin;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class ESB_DateModule extends \Elementor\Widget_Base
{

	/**
	 * Retrieve Alert widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{

		return 'event_date_module';
	}

	/**
	 * Retrieve Alert widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title()
	{

		return __('Event Date Module', 'mec-single-builder');
	}

	/**
	 * Retrieve Alert widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon()
	{

		return 'fa fa-calendar';
	}

	/**
	 * Set widget category.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories()
	{

		return ['single_builder'];
	}

	/**
	 * Register Alert widget controls.
	 *
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls()
	{

		$this->start_controls_section(
			'mec_date_box',
			array(
				'label' 	=> __('Date Box', 'mec-single-builder'),
				'tab'   	=> \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'mec_date_box_bg_color', //param_name
			[
				'label' 		=> __('Background Color', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::COLOR, //type
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-date' => 'background: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'mec_date_box_padding', //param_name
			[
				'label' 		=> __('Padding', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-date' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'mec_date_box_margin', //param_name
			[
				'label' 		=> __('Margin', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-date' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 			=> 'mec_date_box_border',
				'label' 		=> __('Border', 'mec-single-builder'),
				'selector' 		=> '{{WRAPPER}} .mec-single-event-date',
			]
		);

		$this->add_control(
			'mec_date_box_shape_radius', //param_name
			[
				'label' 		=> __('Border Radius', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-date' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' 		=> 'mec_date_box_box_shadow',
				'label' 	=> __('Box Shadow', 'mec-single-builder'),
				'selector' 	=> '{{WRAPPER}} .mec-single-event-date',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'mec_date_typography',
			array(
				'label' 	=> __('Date Typography', 'mec-single-builder'),
				'tab'   	=> \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'mec_date_typography_title',
				'label' 	=> __('Title Typography', 'mec-single-builder'),
				'selector' 	=> '{{WRAPPER}} .mec-single-event-date .mec-date',
			]
		);

		$this->add_control(
			'mec_date_typography_color',
			[
				'label' 		=> __('Title Color', 'color'),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-date .mec-date' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'mec_date_typography_padding', //param_name
			[
				'label' 		=> __('Title Padding', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-date .mec-date' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'mec_date_typography_icon',
			[
				'label' 		=> __('Icon Size', 'mec-single-builder'),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> ['px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' 		=> [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-date i:before' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'mec_date_typography_icon_color',
			[
				'label' 		=> __('Icon Color', 'color'),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-date i:before' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'mec_date_label_typography_title',
				'label' 	=> __('Label Typography', 'mec-single-builder'),
				'selector' 	=> '{{WRAPPER}} .mec-single-event-date span',
			]
		);

		$this->add_control(
			'mec_date_label_typography_color',
			[
				'label' 		=> __('Label Color', 'color'),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-date span' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'mec_date_label_typography_padding', //param_name
			[
				'label' 		=> __('Label Padding', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-date .mec-events-abbr' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render Alert widget output on the frontend.
	 *
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render()
	{
		global $eventt;
		$mainClass      = new \MEC_main();
		$single         = new \MEC_skin_single();
		$set            = $mainClass->get_settings();
		

		if (Plugin::$instance->editor->is_edit_mode()) {
			$latest_post = get_posts('post_type=mec-events&numberposts=1');
			$eventt = $single->get_event_mec($latest_post[0]->ID);
			$eventt = $eventt[0];
			$occurrence 			= (isset($eventt->date['start']['date']) ? $eventt->date['start']['date'] : (isset($_GET['occurrence']) ? sanitize_text_field($_GET['occurrence']) : ''));
			$occurrence_end_date 	= trim($occurrence) ? $mainClass->get_end_date_by_occurrence($eventt->data->ID, (isset($eventt->date['start']['date']) ? $eventt->date['start']['date'] : $occurrence)) : '';
			echo '<div class="mec-event-meta">';
			// Event Date
			if (isset($eventt->data->meta['mec_date']['start']) and !empty($eventt->data->meta['mec_date']['start'])) {
				?>
			<div class="mec-single-event-date">
				<i class="mec-sl-calendar"></i>
				<h3 class="mec-date"><?php _e('Date', 'mec-single-builder'); ?></h3>
				<dd><abbr class="mec-events-abbr"><?php echo $mainClass->date_label((trim($occurrence) ? array('date' => $occurrence) : $eventt->date['start']), (trim($occurrence_end_date) ? array('date' => $occurrence_end_date) : (isset($eventt->date['end']) ? $eventt->date['end'] : NULL)), $set['single_date_format1']); ?></abbr></dd>
			</div>
			<?php
			echo '</div>';
		}
	} else {
		if ( isset($_GET['preview_id']) and !empty($_GET['preview_id'])) {
			$latest_post = get_posts('post_type=mec-events&numberposts=1');
			$e_id = $latest_post[0]->ID;
		} else {
			$e_id = get_the_ID();
		}
		$eventt = $single->get_event_mec($e_id);
		$eventt = $eventt[0];
		$occurrence 			= (isset($eventt->date['start']['date']) ? $eventt->date['start']['date'] : (isset($_GET['occurrence']) ? sanitize_text_field($_GET['occurrence']) : ''));
		$occurrence_end_date 	= trim($occurrence) ? $mainClass->get_end_date_by_occurrence($eventt->data->ID, (isset($eventt->date['start']['date']) ? $eventt->date['start']['date'] : $occurrence)) : '';
		echo '<div class="mec-event-meta">';
		// Event Date
		if (isset($eventt->data->meta['mec_date']['start']) and !empty($eventt->data->meta['mec_date']['start'])) {
			?>
			<div class="mec-single-event-date">
				<i class="mec-sl-calendar"></i>
				<h3 class="mec-date"><?php _e('Date', 'mec-single-builder'); ?></h3>
				<dd><abbr class="mec-events-abbr"><?php echo $mainClass->date_label((trim($occurrence) ? array('date' => $occurrence) : $eventt->date['start']), (trim($occurrence_end_date) ? array('date' => $occurrence_end_date) : (isset($eventt->date['end']) ? $eventt->date['end'] : NULL)), $set['single_date_format1']); ?></abbr></dd>
			</div>
			<?php
		}
		echo '</div>';
	}
}
}
