<?php
namespace Elementor;

namespace MEC_Single_Builder\Inc\Admin\Widgets;

use Elementor\Plugin;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class ESB_TimeModule extends \Elementor\Widget_Base
{

	/**
	 * Retrieve Alert widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{

		return 'event_time_module';
	}

	/**
	 * Retrieve Alert widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title()
	{

		return __('Event Time Module', 'mec-single-builder');
	}

	/**
	 * Retrieve Alert widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon()
	{

		return 'fa fa-clock-o';
	}

	/**
	 * Set widget category.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget category.
	 */
	public function get_categories()
	{

		return ['single_builder'];
	}

	/**
	 * Register Alert widget controls.
	 *
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls()
	{

		$this->start_controls_section(
			'mec_time_box',
			array(
				'label' 	=> __('Time Box', 'mec-single-builder'),
				'tab'   	=> \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'mec_time_box_bg_color', //param_name
			[
				'label' 		=> __('Background Color', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::COLOR, //type
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-time' => 'background: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'mec_time_box_padding', //param_name
			[
				'label' 		=> __('Padding', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-time' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'mec_time_box_margin', //param_name
			[
				'label' 		=> __('Margin', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-time' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 			=> 'mec_time_box_border',
				'label' 		=> __('Border', 'mec-single-builder'),
				'selector' 		=> '{{WRAPPER}} .mec-single-event-time',
			]
		);

		$this->add_control(
			'mec_time_box_shape_radius', //param_name
			[
				'label' 		=> __('Border Radius', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-time' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' 		=> 'mec_time_box_box_shadow',
				'label' 	=> __('Box Shadow', 'mec-single-builder'),
				'selector' 	=> '{{WRAPPER}} .mec-single-event-time',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'mec_time_typography',
			array(
				'label' 	=> __('Time Typography', 'mec-single-builder'),
				'tab'   	=> \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'mec_time_typography_title',
				'label' 	=> __('Title Typography', 'mec-single-builder'),
				'selector' 	=> '{{WRAPPER}} .mec-single-event-time .mec-time',
			]
		);

		$this->add_control(
			'mec_time_typography_color',
			[
				'label' 		=> __('Title Color', 'color'),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-time .mec-time' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'mec_time_typography_padding', //param_name
			[
				'label' 		=> __('Title Padding', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-time .mec-time' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'mec_time_typography_icon',
			[
				'label' 		=> __('Icon Size', 'mec-single-builder'),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> ['px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' 		=> [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-time i:before' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'mec_time_typography_icon_color',
			[
				'label' 		=> __('Label Color', 'color'),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-time i:before' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'mec_time_label_typography_title',
				'label' 	=> __('Label Typography', 'mec-single-builder'),
				'selector' 	=> '{{WRAPPER}} .mec-single-event-time .mec-events-abbr',
			]
		);

		$this->add_control(
			'mec_time_label_typography_color',
			[
				'label' 		=> __('Label Color', 'color'),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-time .mec-events-abbr' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'mec_time_label_typography_padding', //param_name
			[
				'label' 		=> __('Label Padding', 'mec-single-builder'), //heading
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS, //type
				'size_units' 	=> ['px', 'em', '%'],
				'selectors' 	=> [
					'{{WRAPPER}} .mec-single-event-time .mec-events-abbr' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render Alert widget output on the frontend.
	 *
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render()
	{
		global $eventt;
		$single         = new \MEC_skin_single();

		if (Plugin::$instance->editor->is_edit_mode()) {
			$latest_post = get_posts('post_type=mec-events&numberposts=1');

			$eventt = $single->get_event_mec($latest_post[0]->ID);
			$eventt = $eventt[0];
			echo '<div class="mec-event-meta">';
			// Event Time
			if (isset($eventt->data->meta['mec_date']['start']) and !empty($eventt->data->meta['mec_date']['start'])) {
				if (isset($eventt->data->meta['mec_hide_time']) and $eventt->data->meta['mec_hide_time'] == '0') {
					$time_comment = isset($eventt->data->meta['mec_comment']) ? $eventt->data->meta['mec_comment'] : '';
					$allday = isset($eventt->data->meta['mec_allday']) ? $eventt->data->meta['mec_allday'] : 0;
					?>
				<div class="mec-single-event-time">
					<i class="mec-sl-clock " style=""></i>
					<h3 class="mec-time"><?php _e('Time', 'mec-single-builder'); ?></h3>
					<i class="mec-time-comment"><?php echo (isset($time_comment) ? $time_comment : ''); ?></i>
					<?php if ($allday == '0' and isset($eventt->data->time) and trim($eventt->data->time['start'])) : ?>
						<dd><abbr class="mec-events-abbr"><?php echo $eventt->data->time['start']; ?><?php echo (trim($eventt->data->time['end']) ? ' - ' . $eventt->data->time['end'] : ''); ?></abbr></dd>
					<?php else : ?>
						<dd><abbr class="mec-events-abbr"><?php _e('All of the day', 'mec-single-builder'); ?></abbr></dd>
					<?php endif; ?>
				</div>
				<?php
				}
			}
		echo '</div>';
		} else {
			if ( isset($_GET['preview_id']) and !empty($_GET['preview_id'])) {
				$latest_post = get_posts('post_type=mec-events&numberposts=1');
				$e_id = $latest_post[0]->ID;
			} else {
				$e_id = get_the_ID();
			}
			$eventt = $single->get_event_mec($e_id);
			$eventt = $eventt[0];
			echo '<div class="mec-event-meta">';
			// Event Time
			if (isset($eventt->data->meta['mec_date']['start']) and !empty($eventt->data->meta['mec_date']['start'])) {
				if (isset($eventt->data->meta['mec_hide_time']) and $eventt->data->meta['mec_hide_time'] == '0') {
					$time_comment = isset($eventt->data->meta['mec_comment']) ? $eventt->data->meta['mec_comment'] : '';
					$allday = isset($eventt->data->meta['mec_allday']) ? $eventt->data->meta['mec_allday'] : 0;
					?>
						<div class="mec-single-event-time">
							<i class="mec-sl-clock " style=""></i>
							<h3 class="mec-time"><?php _e('Time', 'mec-single-builder'); ?></h3>
							<i class="mec-time-comment"><?php echo (isset($time_comment) ? $time_comment : ''); ?></i>

							<?php if ($allday == '0' and isset($eventt->data->time) and trim($eventt->data->time['start'])) : ?>
								<dd><abbr class="mec-events-abbr"><?php echo $eventt->data->time['start']; ?><?php echo (trim($eventt->data->time['end']) ? ' - ' . $eventt->data->time['end'] : ''); ?></abbr></dd>
							<?php else : ?>
								<dd><abbr class="mec-events-abbr"><?php _e('All of the day', 'mec-single-builder'); ?></abbr></dd>
							<?php endif; ?>
						</div>
					<?php
				}
			}
			echo '</div>';
		}
}
}
