<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use \Elementor\Scheme_Color;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;

/** no direct access */
defined( 'MECEXEC' ) or die();

/**
 * Webnus MEC elementor addon shortcode class
 *
 * @author Webnus <info@webnus.net>
 */
class MecShortCodeDesignerCountdown extends Widget_Base {

	/**
	 * Retrieve MEC widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'mec-countdown';
	}

	/**
	 * Retrieve MEC widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'MEC Countdown', 'mec-shortcode-designer' );
	}

	/**
	 * Retrieve MEC widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-countdown';
	}


	/**
	 * Set widget category.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget category.
	 */
	public function get_categories() {
		return [ 'mec_shortcode_designer' ];
	}

	/**
	 * Register MEC widget controls.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		// typography
		$this->start_controls_section(
			'styling_section',
			[
				'label' => __( 'Typography', 'mec-shortcode-designer' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'		=> 'number_typography',
				'label'		=> __( 'ٔNumber Typography', 'mec-shortcode-designer' ),
				'scheme'	=> Scheme_Typography::TYPOGRAPHY_1,
				'selector'	=> '{{WRAPPER}} .mec-shortcode-designer .mec-event-countdown .block-w span',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'		=> 'label_typography',
				'label'		=> __( 'Label Typography', 'mec-shortcode-designer' ),
				'scheme'	=> Scheme_Typography::TYPOGRAPHY_1,
				'selector'	=> '{{WRAPPER}} .mec-shortcode-designer .mec-event-countdown .block-w p',
			]
		);
		$this->add_control(
			'countdown_align',
			[
				'label'		=> __( 'Alignment', 'mec-shortcode-designer' ),
				'type'		=> Controls_Manager::CHOOSE,
				'options'	=> [
					'left' => [
						'title' => __( 'Left', 'mec-shortcode-designer' ),
						'icon'	=> 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'mec-shortcode-designer' ),
						'icon'	=> 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'mec-shortcode-designer' ),
						'icon'	=> 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'selectors' => [
					'{{WRAPPER}} .mec-shortcode-designer .mec-event-countdown' => 'text-align: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'display',
			[
				'label'		=> __( 'Display', 'mec-shortcode-designer' ),
				'type'		=> Controls_Manager::SELECT,
				'default' 	=> 'block',
				'options' 	=> [
					'inherit'		=> __( 'inherit', 'mec-shortcode-designer' ),
					'inline'		=> __( 'inline', 'mec-shortcode-designer' ),
					'inline-block'	=> __( 'inline-block', 'mec-shortcode-designer' ),
					'block'			=> __( 'block', 'mec-shortcode-designer' ),
					'none'			=> __( 'none', 'mec-shortcode-designer' ),
				],
				'selectors' => [
					'{{WRAPPER}} .mec-shortcode-designer .mec-event-countdown' => 'display: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();
		// color
		$this->start_controls_section(
			'countdown_color_style',
			[
				'label' => __( 'Colors', 'mec-shortcode-designer' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'number_color',
			[
				'label'		=> __( 'ٔNumber Color', 'mec-shortcode-designer' ),
				'type'		=> Controls_Manager::COLOR,
				'scheme'	=> [
					'type'	=> Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default'	=> '#40d9f1',
				'selectors' => [
					'{{WRAPPER}} .mec-shortcode-designer .mec-event-countdown .block-w span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'label_color',
			[
				'label'		=> __( 'Label Color', 'mec-shortcode-designer' ),
				'type'		=> Controls_Manager::COLOR,
				'scheme'	=> [
					'type'	=> Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default'	=> '#40d9f1',
				'selectors' => [
					'{{WRAPPER}} .mec-shortcode-designer .mec-event-countdown .block-w p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();
		// background
		$this->start_controls_section(
			'countdown_background_style',
			[
				'label' => __( 'Background', 'mec-shortcode-designer' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'countdown_background',
			[
				'label'		=> __( 'Background', 'mec-shortcode-designer' ),
				'type'		=> Controls_Manager::COLOR,
				'scheme'	=> [
					'type'	=> Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default'	=> 'rgba(255,255,255,01)',
				'selectors' => [
					'{{WRAPPER}} .mec-shortcode-designer .mec-event-countdown' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'countdown_hover_background',
			[
				'label'		=> __( 'Background Hover', 'mec-shortcode-designer' ),
				'type'		=> Controls_Manager::COLOR,
				'scheme'	=> [
					'type'	=> Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default'	=> 'rgba(255,255,255,0)',
				'selectors' => [
					'{{WRAPPER}} .mec-shortcode-designer .mec-event-countdown:hover' => 'background: {{VALUE}}',
				],
			]
		);


		$this->end_controls_section();
		// Spacing
		$this->start_controls_section(
			'countdown_spacing_style',
			[
				'label' => __( 'Block Spacing', 'mec-shortcode-designer' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'block_margin',
			[
				'label'			=> __( 'Margin', 'mec-shortcode-designer' ),
				'type'			=> Controls_Manager::DIMENSIONS,
				'size_units'	=> [ 'px', '%', 'em' ],
				'default'		=> [
					'top'		=> '0',
					'right'		=> '0',
					'bottom'	=> '0',
					'left'		=> '0',
					'isLinked' => true,
				],
				'selectors'		=> [
					'{{WRAPPER}} .mec-shortcode-designer .mec-event-countdown .block-w' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'block_padding',
			[
				'label'			=> __( 'Padding', 'mec-shortcode-designer' ),
				'type'			=> Controls_Manager::DIMENSIONS,
				'size_units'	=> [ 'px', '%', 'em' ],
				'selectors'		=> [
					'{{WRAPPER}} .mec-shortcode-designer .mec-event-countdown .block-w' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		// Box Settings
		$this->start_controls_section(
			'box_style',
			[
				'label' => __( 'Box Settings', 'mec-shortcode-designer' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'box_margin',
			[
				'label'			=> __( 'Margin', 'mec-shortcode-designer' ),
				'type'			=> Controls_Manager::DIMENSIONS,
				'size_units'	=> [ 'px', '%', 'em' ],
				'default'		=> [
					'top'		=> '0',
					'right'		=> '0',
					'bottom'	=> '0',
					'left'		=> '0',
					'isLinked' => true,
				],
				'selectors'		=> [
					'{{WRAPPER}} .mec-shortcode-designer .mec-event-countdown' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'box_padding',
			[
				'label'			=> __( 'Padding', 'mec-shortcode-designer' ),
				'type'			=> Controls_Manager::DIMENSIONS,
				'size_units'	=> [ 'px', '%', 'em' ],
				'selectors'		=> [
					'{{WRAPPER}} .mec-shortcode-designer .mec-event-countdown' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'		=> 'box_border',
				'label'		=> __( 'Border', 'mec-shortcode-designer' ),
				'selector'	=> '{{WRAPPER}} .mec-shortcode-designer .mec-event-countdown',
			]
		);
		$this->add_control(
			'countdown_border_radius', //param_name
			[
				'label' 		=> __( 'Border Radius', 'mec-shortcode-designer' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .mec-shortcode-designer .mec-event-countdown' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);		
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'label' => __( 'Box Shadow', 'plugin-domain' ),
				'selector' => '{{WRAPPER}} .mec-shortcode-designer .mec-event-countdown',
			]
		);
		$this->end_controls_section();
	}

	/**
	 * Render MEC widget output on the frontend.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings   = $this->get_settings();
		$main = new MEC_main();
		$mec_settings = $main->get_settings();
		if ( get_post_type() == 'mec_designer' ) {
			$event_id = get_posts( 'post_type=mec-events&numberposts=1' )[0]->ID;

			$start_date = get_post_meta($event_id, 'mec_start_date', true);;
			$end_date = get_post_meta($event_id, 'mec_end_date', true);;

			$event_time = '';
			$event_time .= sprintf("%02d", (!empty(get_post_meta( $event_id, 'mec_start_time_ampm', true)) ? get_post_meta( $event_id, 'mec_start_time_ampm', true) : 8)).':';
			$event_time .= sprintf("%02d", (!empty(get_post_meta( $event_id, 'mec_start_time_minutes', true)) ? get_post_meta( $event_id, 'mec_start_time_minutes', true) : 0));
			$event_time .= (!empty(get_post_meta( $event_id, 'mec_start_time_ampm', true)) ? get_post_meta( $event_id, 'mec_start_time_ampm', true) : 'AM');

			$event_etime = '';
			$event_etime .= sprintf("%02d", (!empty(get_post_meta( $event_id, 'mec_end_time_hour', true)) ? get_post_meta( $event_id, 'mec_end_time_hour', true) : 6)).':';
			$event_etime .= sprintf("%02d", (!empty(get_post_meta( $event_id, 'mec_end_time_minutes', true)) ? get_post_meta( $event_id, 'mec_end_time_minutes', true) : 0));
			$event_etime .= (!empty(get_post_meta( $event_id, 'mec_end_time_ampm', true)) ? get_post_meta( $event_id, 'mec_end_time_ampm', true) : 'PM');

			$start_time = date('D M j Y G:i:s', strtotime($start_date.' '.date('H:i:s', strtotime($event_time))));
			$end_time = date('D M j Y G:i:s', strtotime($end_date.' '.date('H:i:s', strtotime($event_etime))));

			$d1 = new DateTime($start_time);
			$d2 = new DateTime(current_time("D M j Y G:i:s"));
			$d3 = new DateTime($end_time);

			$ongoing = (isset($mec_settings['hide_time_method']) and trim($mec_settings['hide_time_method']) == 'end') ? true : false;
			

			$gmt_offset = $main->get_gmt_offset();
			if(isset($_SERVER['HTTP_USER_AGENT']) and strpos($_SERVER['HTTP_USER_AGENT'], 'Safari') === false) $gmt_offset = ' : '.$gmt_offset;
			if(isset($_SERVER['HTTP_USER_AGENT']) and strpos($_SERVER['HTTP_USER_AGENT'], 'Edge') == true) $gmt_offset = substr(trim($gmt_offset), 0 , 3);
			if(isset($_SERVER['HTTP_USER_AGENT']) and strpos($_SERVER['HTTP_USER_AGENT'], 'Trident') == true) $gmt_offset = substr(trim($gmt_offset), 2 , 3);

			$javascript = '
			<script type="text/javascript">
				jQuery(document).ready(function()
				{
					jQuery("#mec_skin_custom_countdown").mecCountDown(
					{
						date: "'.(($ongoing and (!empty(get_post_meta( $event_id, 'mec_repeat_status', true)) and get_post_meta( $event_id, 'mec_repeat_status', true) == 0)) ? $end_time : $start_time).$gmt_offset.'",
						format: "off"
					},
					function()
					{
					});
				});
			</script>';
			echo $javascript;
			?>
			<div class="mec-shortcode-designer">
				<div class="mec-event-countdown" id="mec_skin_custom_countdown">
					<ul class="clockdiv" id="countdown">
						<div class="days-w block-w">
							<li>
								<span class="mec-days">00</span>
								<p class="mec-timeRefDays label-w"><?php _e('days', 'mec'); ?></p>
							</li>
						</div>
						<div class="hours-w block-w">
							<li>
								<span class="mec-hours">00</span>
								<p class="mec-timeRefHours label-w"><?php _e('hours', 'mec'); ?></p>
							</li>
						</div>  
						<div class="minutes-w block-w">
							<li>
								<span class="mec-minutes">00</span>
								<p class="mec-timeRefMinutes label-w"><?php _e('minutes', 'mec'); ?></p>
							</li>
						</div>
						<div class="seconds-w block-w">
							<li>
								<span class="mec-seconds">00</span>
								<p class="mec-timeRefSeconds label-w"><?php _e('seconds', 'mec'); ?></p>
							</li>
						</div>
					</ul>
				</div>
			</div>
			<?php
		} else {
			static $i = 0;
			$start_date = get_option( 'mec_sd_time_option' );
			$end_date = get_option( 'mec_esd_time_option' );


			$event_time = '';
			$event_time .= sprintf("%02d", (!empty(get_post_meta( get_the_ID(), 'mec_start_time_ampm', true)) ? get_post_meta( get_the_ID(), 'mec_start_time_ampm', true) : 8)).':';
			$event_time .= sprintf("%02d", (!empty(get_post_meta( get_the_ID(), 'mec_start_time_minutes', true)) ? get_post_meta( get_the_ID(), 'mec_start_time_minutes', true) : 0));
			$event_time .= (!empty(get_post_meta( get_the_ID(), 'mec_start_time_ampm', true)) ? get_post_meta( get_the_ID(), 'mec_start_time_ampm', true) : 'AM');

			$event_etime = '';
			$event_etime .= sprintf("%02d", (!empty(get_post_meta( get_the_ID(), 'mec_end_time_hour', true)) ? get_post_meta( get_the_ID(), 'mec_end_time_hour', true) : 6)).':';
			$event_etime .= sprintf("%02d", (!empty(get_post_meta( get_the_ID(), 'mec_end_time_minutes', true)) ? get_post_meta( get_the_ID(), 'mec_end_time_minutes', true) : 0));
			$event_etime .= (!empty(get_post_meta( get_the_ID(), 'mec_end_time_ampm', true)) ? get_post_meta( get_the_ID(), 'mec_end_time_ampm', true) : 'PM');

			$start_time = date('D M j Y G:i:s', strtotime($start_date.' '.date('H:i:s', strtotime($event_time))));
			$end_time = date('D M j Y G:i:s', strtotime($end_date.' '.date('H:i:s', strtotime($event_etime))));

			$d1 = new DateTime($start_time);
			$d2 = new DateTime(current_time("D M j Y G:i:s"));
			$d3 = new DateTime($end_time);

			$ongoing = (isset($mec_settings['hide_time_method']) and trim($mec_settings['hide_time_method']) == 'end') ? true : false;

			$ongoing = (isset($mec_settings['hide_time_method']) and trim($mec_settings['hide_time_method']) == 'end') ? true : false;
			if($ongoing) if($d3 < $d2) $ongoing = false;

			// Skip if event is ongoing
			if($d1 < $d2 and !$ongoing) return;

			$gmt_offset = $main->get_gmt_offset();
			if(isset($_SERVER['HTTP_USER_AGENT']) and strpos($_SERVER['HTTP_USER_AGENT'], 'Safari') === false) $gmt_offset = ' : '.$gmt_offset;
			if(isset($_SERVER['HTTP_USER_AGENT']) and strpos($_SERVER['HTTP_USER_AGENT'], 'Edge') == true) $gmt_offset = substr(trim($gmt_offset), 0 , 3);
			if(isset($_SERVER['HTTP_USER_AGENT']) and strpos($_SERVER['HTTP_USER_AGENT'], 'Trident') == true) $gmt_offset = substr(trim($gmt_offset), 2 , 3);


			$javascript = '
			<script type="text/javascript">
				jQuery(document).ready(function()
				{
					jQuery("#mec_skin_custom_countdown'. $i .'").mecCountDown(
					{
						date: "'.(($ongoing and (!empty(get_post_meta( get_the_ID(), 'mec_repeat_status', true)) and get_post_meta( get_the_ID(), 'mec_repeat_status', true) == 0)) ? $end_time : $start_time).$gmt_offset.'",
						format: "off"
					},
					function()
					{
					});
				});
			</script>';
			$data_date_custom = (($ongoing and (!empty(get_post_meta( get_the_ID(), 'mec_repeat_status', true)) and get_post_meta( get_the_ID(), 'mec_repeat_status', true) == 0)) ? $end_time : $start_time).$gmt_offset;
			echo $javascript;

			?>
			<div class="mec-shortcode-designer">
				<div class="mec-event-countdown mec-event-sd-countdown" data-date-custom="<?php echo $data_date_custom; ?>" id="mec_skin_custom_countdown<?php echo $i; ?>">
					<ul class="clockdiv" id="countdown">
						<div class="days-w block-w">
							<li>
								<span class="mec-days">00</span>
								<p class="mec-timeRefDays label-w"><?php _e('days', 'mec'); ?></p>
							</li>
						</div>
						<div class="hours-w block-w">
							<li>
								<span class="mec-hours">00</span>
								<p class="mec-timeRefHours label-w"><?php _e('hours', 'mec'); ?></p>
							</li>
						</div>  
						<div class="minutes-w block-w">
							<li>
								<span class="mec-minutes">00</span>
								<p class="mec-timeRefMinutes label-w"><?php _e('minutes', 'mec'); ?></p>
							</li>
						</div>
						<div class="seconds-w block-w">
							<li>
								<span class="mec-seconds">00</span>
								<p class="mec-timeRefSeconds label-w"><?php _e('seconds', 'mec'); ?></p>
							</li>
						</div>
					</ul>
				</div>
			</div>
			<?php
			$i++;
		}
	}
}
