<?php
namespace Elementor;

/** no direct access **/
defined('MECEXEC') or die();

/**
 * Webnus MEC elementor search form filter_options view class
 * @author Webnus <info@webnus.biz>
 */
class MEC_elementor_filter_options
{

    /**
     * Register Elementor search form filter_options options 
     * @author Webnus <info@webnus.biz>
     */
    public static function options( $self )
    {
		// Categories
        $terms = get_terms( 'mec_category' );
        $categories = array();
        if ($terms) {
            foreach ($terms as $term) {
                $categories[$term->term_id] = $term->name;
            }
        }
		$self->add_control(
            // mec_sk_options_
			'filter_options_categories',
			array(
				'label'		=> __('Categories', 'mec-shortcode-builder'),
                'type'		=> \Elementor\Controls_Manager::SELECT2,
                'multiple'  => true,
				'options'	=> $categories,
            )
        );

        // locations
        $terms = get_terms( 'mec_location' );
        $locations = array();
        if ($terms) {
            foreach ($terms as $term) {
                $locations[$term->term_id] = $term->name;
            }
        }
		$self->add_control(
            // mec_sk_options_
			'filter_options_locations',
			array(
				'label'		=> __('Locations', 'mec-shortcode-builder'),
                'type'		=> \Elementor\Controls_Manager::SELECT2,
                'multiple'  => true,
				'options'	=> $locations,
            )
        );

        // organizers
        $terms = get_terms( 'mec_organizer' );
        $organizers = array();
        if ($terms) {
            foreach ($terms as $term) {
                $organizers[$term->term_id] = $term->name;
            }
        }
		$self->add_control(
            // sk_options_
			'filter_options_organizers',
			array(
				'label'		=> __('Organizers', 'mec-shortcode-builder'),
                'type'		=> \Elementor\Controls_Manager::SELECT2,
                'multiple'  => true,
				'options'	=> $organizers,
            )
        );

        // labels
        $terms = get_terms( 'mec_label' );
        $labels = array();
        if ($terms) {
            foreach ($terms as $term) {
                $labels[$term->term_id] = $term->name;
            }
        }
		$self->add_control(
            // sk_options_
			'filter_options_labels',
			array(
				'label'		=> __('Labels', 'mec-shortcode-builder'),
                'type'		=> \Elementor\Controls_Manager::SELECT2,
                'multiple'  => true,
				'options'	=> $labels,
            )
        );

        // tags
        $terms = get_terms( 'post_tag' );
        $tags = array();
        if ($terms) {
            foreach ($terms as $term) {
                $tags[$term->name] = $term->name;
            }
        }
		$self->add_control(
            // mec_sk_options_
			'filter_options_tags',
			array(
				'label'		=> __('Tags', 'mec-shortcode-builder'),
                'type'		=> \Elementor\Controls_Manager::SELECT2,
                'multiple'  => true,
				'options'	=> $tags,
            )
        );

        // authors
        $authors            = array();
        $users              = get_users(array(
            'role__not_in'  => array('Subscriber', 'contributor'),
            'orderby'       => 'post_count',
            'order'         => 'DESC',
            'number'        => '-1',
            'fields'        => array('ID', 'display_name')
        ));
        if ($users) {
            foreach ($users as $author) {
                $authors[$author->ID] = $author->display_name;
            }
        }
		$self->add_control(
            // mec_sk_options_
			'filter_options_authors',
			array(
				'label'		=> __('Authors', 'mec-shortcode-builder'),
                'type'		=> \Elementor\Controls_Manager::SELECT2,
                'options'	=> $authors,
                'multiple'  => true,
            )
        );

		$self->add_control(
            // mec_sk_options_
			'filter_options_dates',
			array(
				'label'		=> __('Dates', 'mec-shortcode-builder'),
                'type'		=> \Elementor\Controls_Manager::SELECT2,
                'default'	=> 'include-expired-events',
                'options'	=> [
                    'include-expired-events'    => __('Include Expired Events','mec'),
                    'show-only-expired-events'  => __('Show Only Expired Events','mec'),
                    'show-only-ongoing-events'  => __('Show Only Ongoing Events','mec'),
                ],
            )
        );
    }
}